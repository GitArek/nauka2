let firstRunFile = "data_p1.txt";
let fileInfo = ["data_p", ".txt"];
let fileAlert = "File downolad error";
let fullTableId = [];
let JSONTable = [];

$(document).ready(function(){
    loadFile(firstRunFile,"1");
});
$(document).ready(function(){
    $("th input").click(function(){
        let stream = document.getElementsByTagName("tbody")[0].innerHTML;
        let stream2 =
            stream.replace(/input type="checkbox"/g, 'input type=\"checkbox\" checked');
        document.getElementsByTagName("tbody")[0].innerHTML = stream2;
    });
});

$(document).ready(function(){
    $("button").click(function(){
        document.getElementsByTagName("tbody")[0].innerHTML = "";
        let id = this.id.slice(this.id.length-1);
        let fullFile = `${fileInfo[0]}${id}${fileInfo[1]}`
        loadFile(fullFile,id);
    });
});

function loadFile(file,id) {

    id = Number(id);

    function checkData(currentValue,index){
        return currentValue==id
    }

    if(fullTableId.find(checkData)==undefined) {

        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                let tableDate = JSON.parse(this.responseText);
                fullTableId.push(id);
                JSONTable.push(tableDate);
                createTable(tableDate, id);
            }
            else if (this.readyState == 4 && this.status != 200) {
                alert(fileAlert);
            }
        };
        xhttp.open("GET", file, true);
        xhttp.send();
    }
    else{
        for(let l=0; l < fullTableId.length; l++){
            if(fullTableId[l]==id){
                createTable(JSONTable[l], id);
                break;
            }
        }
    }
}

function createTable(tableDate,id) {

    let table = "";

    for (i in tableDate.rows) {
        table += "<tr><td><input type=\"checkbox\"></td>";
        for (k in tableDate.rows[i]) {
            if (k == "gender") break;
            table += "<td>" + tableDate.rows[i][k] + "</td>"
        }
        table += "</tr>";
    }
    document.getElementsByTagName("tbody")[0].innerHTML = table;
}