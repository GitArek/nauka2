let globalParameters ={
    rows : [],
    numberPagination : 10,
    page : 1
};

$(document).ready(function(){
    let firstRunFile = "data_p1.txt";
    loadFile(firstRunFile,"1");
});

$(document).ready(function(){
    $("button").click(function(){
        let fileInfo = ["data_p", ".txt"];
        document.getElementsByTagName("tbody")[0].innerHTML = "";
        globalParameters.page = this.id.slice(this.id.length-1);
        let fullFile = `${fileInfo[0]}${globalParameters.page}${fileInfo[1]}`;
        loadFile(fullFile);
    });
});

function loadFile(file) {
    let localRows = globalParameters.rows;
    let localPage = Number(globalParameters.page);
    let localPagination = globalParameters.numberPagination;

    if(localRows[1+(localPage-1)*localPagination] == undefined)
        {
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                let tableDate = JSON.parse(this.responseText);

                let row = [];

                for (i in tableDate.rows) {
                    let kk=0;
                    for (k in tableDate.rows[i]) {
                       row[kk] = tableDate.rows[i][k];
                       kk++;
                    }
                    row[5]=false;
                    localRows[row[0]]=row.slice();
                }
                createTable();
            }
            else if (this.readyState == 4 && this.status != 200) {
                let fileAlert = "File downolad error";
                document.getElementsByTagName("input")[0].checked = false;
                alert(fileAlert);
            }
        };
        xhttp.open("GET", file, true);
        xhttp.send();
    }
    else{
        createTable();
    }
}

function createTable() {
    let localRows = globalParameters.rows;
    let localPage = globalParameters.page;
    let localPagination = globalParameters.numberPagination;
    let table = "";

    for(let i=1+(localPage-1)*localPagination; i<=localPagination*localPage; i++){
        if(localRows[i][5]==false){
            table += "<tr><td><input type=\"checkbox\" onclick='clickFunction(" + i + ")'></td>";
        }else{
            table += "<tr><td><input type=\"checkbox\" onclick='clickFunction(" + i + ")' checked></td>";
        }

        for(let k=0; k<=3; k++){
            table += "<td>" + localRows[i][k] + "</td>"
        }
    }
    table += "</tr>";
    document.getElementsByTagName("tbody")[0].innerHTML = table;

    let chceckedInput = true;

    for(let i=1+(localPage-1)*localPagination; i<=localPage*localPagination;i++){
        chceckedInput *= localRows[i][5];
    }

    if(chceckedInput){
        document.getElementsByTagName("input")[0].checked = true;
    }else{
        document.getElementsByTagName("input")[0].checked = false;
    }
}

function clickFunction(index){
    let localRows = globalParameters.rows;
    let localPagination = globalParameters.numberPagination;

    localRows[index][5]=!localRows[index][5];
    let chceckedInput = true;

    if(index%localPagination!=0){
        for(let i=1+(index-index%localPagination); i<=10+(index-index%localPagination);i++){
            chceckedInput *= localRows[i][5];
        }
    }else{
        for(let i=1+(index-localPagination); i<=index;i++){
            chceckedInput *= localRows[i][5];
        }
    }

    if(chceckedInput){
        document.getElementsByTagName("input")[0].checked = true;
    }else{
        document.getElementsByTagName("input")[0].checked = false;
    }
}

$(document).ready(function(){
    $("input").click(function(){
        let localRows = globalParameters.rows;
        let localPage = globalParameters.page;
        let localPagination = globalParameters.numberPagination;

            if(document.getElementsByTagName("input")[0].checked == true) {
                for(let i=1+(localPage-1)*localPagination;i<=localPage*localPagination;i++){
                    localRows[i][5] = true
                    createTable(localRows,localPage,localPagination);
                }
            }
    });
});
